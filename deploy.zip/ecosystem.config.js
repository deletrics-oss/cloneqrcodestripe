module.exports = {
  apps: [{
    name: "chatbot-saas",
    script: "./dist/index.js",
    instances: 1, // Start with 1 instance for safety with stateful connections (WhatsApp/Socket.io)
    exec_mode: "fork",
    env: {
      NODE_ENV: "production",
      PORT: 3000
    }
  }]
}
